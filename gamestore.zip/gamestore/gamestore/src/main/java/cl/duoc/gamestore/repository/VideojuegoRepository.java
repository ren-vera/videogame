package cl.duoc.gamestore.repository;

import cl.duoc.gamestore.model.Videojuego;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideojuegoRepository extends JpaRepository<Videojuego, Long> {

}
