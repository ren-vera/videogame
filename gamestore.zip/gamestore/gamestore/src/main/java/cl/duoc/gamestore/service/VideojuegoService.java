package cl.duoc.gamestore.service;

import cl.duoc.gamestore.model.Videojuego;
import cl.duoc.gamestore.repository.VideojuegoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class VideojuegoService {

    private final VideojuegoRepository repo;
    public VideojuegoService(VideojuegoRepository repo){
        this.repo = repo;
    }

    //METODO PARA OBTENER

    public List<Videojuego> findAll(){
        return repo.findAll();
    }

    //METODO PARA GUARDAR

    public Videojuego save(Videojuego videojuego){
        return repo.save(videojuego);
    }

    //METODO PARA ELIMINAR
    public void delete (Long id){
        repo.deleteById(id);
    }
}
