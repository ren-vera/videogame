package cl.duoc.gamestore.servicetest;

import cl.duoc.gamestore.model.Videojuego;
import cl.duoc.gamestore.repository.VideojuegoRepository;

import cl.duoc.gamestore.service.VideojuegoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

//Mockito || Mock == Simular

import org.mockito.*;
import static org.mockito.Mockito.*;



public class VideojuegoServiceTest {

    //CREANDO INSTANCIA PARA INJECTAR MOCKS
    @InjectMocks
    private VideojuegoService service;

    //CREANDO UNA INSTANCIA PARA REEMPLAZAR EL REPOSITORIO POR DATOS SIMULADOS
    @Mock
    private VideojuegoRepository repo;

    //CONSTRUCTOR
    public VideojuegoServiceTest(){
        //inicializar los Mocks realizados anotados para el test @Mock @InjectMocks
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Testing 1 al servicio del metodo findAll")
    void testFindAll(){
        //1 Simular al repo y a simular un videojuego
        when(repo.findAll()).thenReturn(List.of(new Videojuego(1L,"Super Mario Bross","WII")));
        //
        List<Videojuego> resultado = service.findAll();
        //
        assertEquals(1,resultado.size());
    }


}
